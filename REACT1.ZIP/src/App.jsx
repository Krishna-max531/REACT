// --- Class Definitions (from previous response) ---

class Person {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }

  displayInfo() {
    return `Name: ${this.name}, Age: ${this.age}`;
  }
}

class Student extends Person {
  constructor(name, age, grade) {
    super(name, age);
    this.grade = grade;
  }

  displayInfo() {
    return `${super.displayInfo()}, Grade: ${this.grade}`;
  }

  study() {
    return `${this.name} is studying for their ${this.grade} grade.`;
  }
}

class Teacher extends Person {
  constructor(name, age, subject) {
    super(name, age);
    this.subject = subject;
  }

  displayInfo() {
    return `${super.displayInfo()}, Subject: ${this.subject}`;
  }

  teach() {
    return `${this.name} is teaching ${this.subject}.`;
  }
}

// --- UI Interaction Logic ---

const instances = []; // Array to store all created Person, Student, and Teacher objects
const instancesDisplay = document.getElementById('instancesDisplay');

// Function to update the display area with all created instances
function displayInstances() {
    instancesDisplay.innerHTML = ''; // Clear previous display

    if (instances.length === 0) {
        instancesDisplay.innerHTML = '<p>No instances created yet. Use the forms above!</p>';
        return;
    }

    instances.forEach((instance, index) => {
        const card = document.createElement('div');
        card.className = 'instance-card';

        let details = `<p><strong>Instance ${index + 1} (${instance.constructor.name}):</strong></p>`;
        details += `<p>${instance.displayInfo()}</p>`;

        // Add specific methods if applicable
        if (instance instanceof Student) {
            details += `<p>${instance.study()}</p>`;
        } else if (instance instanceof Teacher) {
            details += `<p>${instance.teach()}</p>`;
        }

        card.innerHTML = details;
        instancesDisplay.appendChild(card);
    });
}

// Functions to handle button clicks and create new objects
function createPerson() {
    const nameInput = document.getElementById('personName');
    const ageInput = document.getElementById('personAge');

    const name = nameInput.value.trim();
    const age = parseInt(ageInput.value);

    if (name && !isNaN(age) && age > 0) {
        const person = new Person(name, age);
        instances.push(person);
        displayInstances();
        nameInput.value = ''; // Clear input fields
        ageInput.value = '';
    } else {
        alert('Please enter a valid name and a positive age for the Person.');
    }
}

function createStudent() {
    const nameInput = document.getElementById('studentName');
    const ageInput = document.getElementById('studentAge');
    const gradeInput = document.getElementById('studentGrade');

    const name = nameInput.value.trim();
    const age = parseInt(ageInput.value);
    const grade = gradeInput.value.trim();

    if (name && !isNaN(age) && age > 0 && grade) {
        const student = new Student(name, age, grade);
        instances.push(student);
        displayInstances();
        nameInput.value = '';
        ageInput.value = '';
        gradeInput.value = '';
    } else {
        alert('Please enter a valid name, positive age, and grade for the Student.');
    }
}

function createTeacher() {
    const nameInput = document.getElementById('teacherName');
    const ageInput = document.getElementById('teacherAge');
    const subjectInput = document.getElementById('teacherSubject');

    const name = nameInput.value.trim();
    const age = parseInt(ageInput.value);
    const subject = subjectInput.value.trim();

    if (name && !isNaN(age) && age > 0 && subject) {
        const teacher = new Teacher(name, age, subject);
        instances.push(teacher);
        displayInstances();
        nameInput.value = '';
        ageInput.value = '';
        subjectInput.value = '';
    } else {
        alert('Please enter a valid name, positive age, and subject for the Teacher.');
    }
}

// Initial display call in case there were pre-loaded instances (not in this example, but good practice)
displayInstances();